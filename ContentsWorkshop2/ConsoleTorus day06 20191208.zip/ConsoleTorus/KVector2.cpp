#include "KVector2.h"

KVector2::KVector2(double tx, double ty)
{
    x = tx;
    y = ty;
}

KVector2::~KVector2()
{
}
