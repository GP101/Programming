﻿#include <iostream>
#include <stack>
#include <Windows.h>
#include <assert.h>
#include <conio.h>

const std::string g_torusText[4] = {
    "RRR",
    "GGG",
    "BBB",
    "MMM",
};

enum TORUS
{
    TORUS_RED = 0,
    TORUS_GREEN,
    TORUS_BLUE,
    TORUS_MAGENTA
};

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void DrawText(int x, int y, const std::string& text)
{
    gotoxy(x, y);
    std::cout << text.c_str();
}

class KStack
{
private:
    TORUS   _buffer[10];
    int     _sp;
    int     _maxSize;

public:
    KStack() {
        _sp = 0;
        _maxSize = 4;
    }
    void Push(TORUS t) {
        if (_sp >= _maxSize)
            return;
        _buffer[_sp] = t;
        _sp += 1;
    }
    void Pop() {
        if (_sp <= 0)
            return;
        _sp -= 1;
    }
    // @pre must not empty
    TORUS Top() {
        return _buffer[_sp - 1];
    }
    bool Empty() {
        return _sp == 0;
    }
    void Draw(int x, int y) {
        int cx = x;
        int cy = y;
        int numTorusInStack = _sp;
        int numEmpty = _maxSize - numTorusInStack;
        for (int i = 0; i < numEmpty; ++i) {
            DrawText(cx, cy, " | ");
            cy += 1;
        }
        const int topIndex = _sp - 1;
        for (int i = topIndex; i >= 0; --i) {
            const TORUS t = _buffer[i];
            assert(t >= 0 && t < 4);
            DrawText(cx, cy, g_torusText[t]);
            cy += 1;
        }
        DrawText(cx, cy, "===");
    }
};

int main()
{
    KStack  s0;
    int ch = 0;
    while (ch != 27) {
        ch = _getch();
        if (ch == 'a')
            s0.Push(TORUS_RED);
        if (ch == 's')
            s0.Push(TORUS_GREEN);
        if (ch == 'x')
            s0.Pop();
        s0.Draw(10, 10);
    }
    return 0;
}