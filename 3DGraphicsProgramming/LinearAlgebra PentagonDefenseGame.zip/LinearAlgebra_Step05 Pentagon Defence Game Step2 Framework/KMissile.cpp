#include "KMissile.h"

KMissile::KMissile()
{
}

KMissile::~KMissile()
{
}

void KMissile::OnUpdate(float fElapsedTime_)
{
	std::cout << "KMissile::OnUpdate()" << std::endl;
}

void KMissile::OnRender(HDC hdc)
{
}
