#include "stdafx.h"
#include "KLight.h"

CONSTRUCTOR KLight::KLight()
{
}

DESTRUCTOR KLight::~KLight()
{
}
