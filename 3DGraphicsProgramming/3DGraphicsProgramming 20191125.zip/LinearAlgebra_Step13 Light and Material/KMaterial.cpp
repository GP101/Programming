#include "stdafx.h"
#include "KMaterial.h"

CONSTRUCTOR KMaterial::KMaterial()
{
}

DESTRUCTOR KMaterial::~KMaterial()
{
}
