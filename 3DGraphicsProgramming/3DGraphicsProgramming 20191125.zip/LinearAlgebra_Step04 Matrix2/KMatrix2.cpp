#include "stdafx.h"
#include "KMatrix2.h"

static KMatrix2 zero = KMatrix2( 0.0f, 0.0f, 0.0f, 0.0f );
static KMatrix2 identity = KMatrix2( 1.0f, 0.0f, 0.0f, 1.0f);
