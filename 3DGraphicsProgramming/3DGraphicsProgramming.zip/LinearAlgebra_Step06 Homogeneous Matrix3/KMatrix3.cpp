#include "stdafx.h"
#include "KMatrix3.h"

static KMatrix3 zero = KMatrix3(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f );
static KMatrix3 identity = KMatrix3(1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f );
