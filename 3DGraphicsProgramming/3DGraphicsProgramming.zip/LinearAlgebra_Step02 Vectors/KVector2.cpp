#include "stdafx.h"
#include "KVector2.h"
