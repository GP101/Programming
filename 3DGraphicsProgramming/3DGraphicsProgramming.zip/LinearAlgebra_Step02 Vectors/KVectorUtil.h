#pragma once
#include <windows.h>
#include "KVector2.h"

namespace KVectorUtil
{
    void DrawLine(HDC hdc, const KVector2& v0, const KVector2& v1);
}
