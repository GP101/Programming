﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class AttributeTest : MonoBehaviour
{
    [Range(0,10)]
    public int _num1;

    [Multiline( 2 )]
    public string _text1;

    [ContextMenuItem( "Random", "RandomNumber" )]
    [ContextMenuItem("Reset","ResetNumber")]
    public int _num2;

    void RandomNumber()
    {
        _num2 = Random.Range( 1, 1000 );
    }
    void ResetNumber()
    {
        _num2 = 0;
    }

    [ContextMenu("Create Cube")]
    void CreateCube()
    {
        GameObject cube = GameObject.CreatePrimitive( PrimitiveType.Cube );
        cube.transform.position = new Vector3( 0, 0, 0 );
    }

    [ColorUsage(false)]
    public Color _color1;

    [HideInInspector]
    public int _num3;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
