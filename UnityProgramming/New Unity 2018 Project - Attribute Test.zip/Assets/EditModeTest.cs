﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class EditModeTest : MonoBehaviour
{
    private int _value = 0;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log( "EditModeTest.Start" );
    }

    // Update is called once per frame
    void Update()
    {
        _value += 1;
        Debug.Log( "EditModeTest.Update"+_value.ToString() );
    }
}
