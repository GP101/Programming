﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
    int _gameDataStamp = 0;
    public Text _coinText;

    // Update is called once per frame
    void Update()
    {
        int stamp = RuntimeGameDataManager.Instance.DataStamp;
        if (_gameDataStamp != stamp)
        {
            _gameDataStamp = stamp;
            _coinText.text = RuntimeGameDataManager.Instance.GetCoinCounter().ToString();
        }
    }
}
