﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// step 1
public class RuntimeGameDataManager : MonoBehaviour
{
    static public RuntimeGameDataManager instance;
    private int _count = 0;
    private bool _isWin = false;
    private int _dataStamp = 0;

    void Awake()
    {
        if (instance == null)
            instance = this;
    }

    public void AddCount(int c)
    {
        _count += 1;
        if (_count >= 12)
            _isWin = true;
        _UpdateDataStamp();
    }

    public int GetCount()
    {
        return _count;
    }

    public bool IsWin()
    {
        return _isWin;
    }

    private void _UpdateDataStamp()
    {
        _dataStamp += 1;
        if (_dataStamp <= 0)
            _dataStamp = 1;
    }
    public int GetDataStamp()
    {
        return _dataStamp;
    }
}
