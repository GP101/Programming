﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SphereController : MonoBehaviour
{
    public Text _text;
    public float _force = 100.0f;
    private Rigidbody _rigidBody;
    private int _counter = 0;

    // Start is called before the first frame update
    void Start()
    {
        _rigidBody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float h = Input.GetAxis( "Horizontal" );
        float v = Input.GetAxis( "Vertical" );
        Vector3 force = new Vector3( h, 0, v );
        force *= _force * Time.fixedDeltaTime;
        _rigidBody.AddForce( force );
    }

    private void OnTriggerEnter( Collider other )
    {
        if( other.CompareTag("Item") )
        {
            _counter += 1;
            _text.text = _counter.ToString();
            other.gameObject.SetActive( false );
        }
    }

}
