﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CubeController : MonoBehaviour
{
    public Text _text;
    public float _velocity = 10.0f;
    public float _accel = 0.0f;
    private Vector3 _v = Vector3.zero;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        float iv = Input.GetAxis( "Vertical" );
        float ih = Input.GetAxis( "Horizontal" );
        float dt = Time.deltaTime;
        Vector3 pos = gameObject.transform.position;

        _v = gameObject.transform.forward * _velocity * iv;
        gameObject.transform.position
            = pos + _v * dt;

        float degree = Mathf.Rad2Deg * (dt * ih);
        Quaternion qprime = Quaternion.AngleAxis( degree, Vector3.up);
        gameObject.transform.rotation =
            gameObject.transform.rotation * qprime;
    }
}
