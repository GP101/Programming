﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysicsTest : MonoBehaviour
{
    public Rigidbody[] _rigid;
    public float _force = 10.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void _AddForce()
    {
        float dt = Time.fixedDeltaTime;
        Vector3 forward = gameObject.transform.forward * _force;
        _rigid[0].AddForce( forward * dt, ForceMode.Impulse );
        _rigid[1].AddForce( forward, ForceMode.Force );
        _rigid[2].AddForce( forward / _rigid[2].mass, ForceMode.Acceleration );
        _rigid[3].AddForce( dt * forward / _rigid[2].mass , ForceMode.VelocityChange );
    }

    // Update is called once per frame
    void Update()
    {
        if( Input.GetKeyDown( KeyCode.A ) )
        {
            _AddForce();
        }
    }
}
